#!/bin/bash
make && echo && echo "build success, wait 3s to run"  && sleep 3 && ./main
